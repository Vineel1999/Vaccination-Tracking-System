import pandas as pd


def schedule_appointment(user_id, vaccine_name, date):
    appointments_file = "database/appointments.csv"

    # Check for existing appointments
    df = pd.read_csv(appointments_file)
    if ((df["User_ID"] == int(user_id)) & (df["Date"] == date)).any():
        raise ValueError("Appointment already exists for this user on this date!")

    # Add new appointment
    new_appointment = {"User_ID": user_id, "Vaccine": vaccine_name, "Date": date}
    df = df.append(new_appointment, ignore_index=True)
    df.to_csv(appointments_file, index=False)
