// Front-end logic for the Vaccine Management System

// Confirmation before scheduling an appointment
function confirmSchedule() {
    const userId = document.getElementById("user_id").value;
    const vaccineName = document.getElementById("vaccine_name").value;
    const date = document.getElementById("date").value;

    if (userId && vaccineName && date) {
        const confirmation = confirm(`Are you sure you want to schedule an appointment?\n\nUser ID: ${userId}\nVaccine: ${vaccineName}\nDate: ${date}`);
        return confirmation;
    } else {
        alert("Please fill in all fields before submitting.");
        return false;
    }
}

// Real-time form validation for User ID
function validateUserId() {
    const userIdField = document.getElementById("user_id");
    const userId = userIdField.value;

    if (!/^\d{4}$/.test(userId)) {
        userIdField.setCustomValidity("User ID must be a 4-digit number.");
        userIdField.reportValidity();
    } else {
        userIdField.setCustomValidity("");
    }
}

// Display a success message for inventory updates
function showInventoryUpdateMessage() {
    const successMessage = document.getElementById("success-message");
    if (successMessage) {
        successMessage.style.display = "block";
        setTimeout(() => {
            successMessage.style.display = "none";
        }, 3000);
    }
}

// Add event listeners to forms
document.addEventListener("DOMContentLoaded", () => {
    const scheduleForm = document.querySelector("form.schedule-form");
    if (scheduleForm) {
        scheduleForm.addEventListener("submit", (event) => {
            if (!confirmSchedule()) {
                event.preventDefault();
            }
        });
    }

    const userIdField = document.getElementById("user_id");
    if (userIdField) {
        userIdField.addEventListener("input", validateUserId);
    }
});
