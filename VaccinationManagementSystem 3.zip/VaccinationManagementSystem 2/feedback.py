import csv

feedback_file = "database/feedback.csv"

def add_feedback(name, message):
    """Add feedback to the system."""
    with open(feedback_file, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([name, message])

def view_feedback():
    """View all feedback."""
    feedback = []
    try:
        with open(feedback_file, "r") as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) == 2:  # Ensure each row has exactly two values
                    feedback.append(row)
                else:
                    print(f"Skipping invalid row: {row}")  # Debugging invalid rows
    except FileNotFoundError:
        pass  # If the file does not exist, return an empty list
    return feedback