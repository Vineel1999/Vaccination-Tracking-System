import pandas as pd


def view_inventory():
    inventory_file = "database/inventory.csv"
    inventory_data = pd.read_csv(inventory_file)
    return inventory_data.to_dict(orient="records")


def update_inventory(vaccine_name, change_qty):
    inventory_file = "database/inventory.csv"
    df = pd.read_csv(inventory_file)
    if vaccine_name in df['Vaccine'].values:
        df.loc[df['Vaccine'] == vaccine_name, 'Quantity'] += change_qty
        df.to_csv(inventory_file, index=False)
    else:
        raise ValueError(f"Vaccine {vaccine_name} not found in inventory.")
