import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email_reminder(recipient_email, subject, message):
    """
    Sends an email reminder to the recipient.
    
    Args:
        recipient_email (str): Email address of the recipient.
        subject (str): Subject of the email.
        message (str): Message body of the email.
    """
    # Email server configuration
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    sender_email = "your_email@example.com"  # Replace with your email
    sender_password = "your_password"       # Replace with your password

    # Create the email
    email = MIMEMultipart()
    email["From"] = sender_email
    email["To"] = recipient_email
    email["Subject"] = subject
    email.attach(MIMEText(message, "plain"))

    # Send the email
    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(email)
        print(f"Email sent to {recipient_email}")
        server.quit()
    except Exception as e:
        print(f"Failed to send email: {e}")


def send_sms_reminder(phone_number, message):
    """
    Sends an SMS reminder to the recipient.
    
    Args:
        phone_number (str): Phone number of the recipient.
        message (str): Message body of the SMS.
    """
    try:
        # Example: Using Twilio for SMS (replace with actual credentials)
        from twilio.rest import Client
        account_sid = "your_account_sid"  # Replace with Twilio Account SID
        auth_token = "your_auth_token"    # Replace with Twilio Auth Token
        client = Client(account_sid, auth_token)

        client.messages.create(
            body=message,
            from_="+1234567890",  # Replace with your Twilio phone number
            to=phone_number
        )
        print(f"SMS sent to {phone_number}")
    except Exception as e:
        print(f"Failed to send SMS: {e}")
