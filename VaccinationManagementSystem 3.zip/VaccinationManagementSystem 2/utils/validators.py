import re
from datetime import datetime

def validate_email(email):
    """
    Validates an email address format.
    
    Args:
        email (str): Email address to validate.
    
    Returns:
        bool: True if the email is valid, False otherwise.
    """
    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(email_regex, email) is not None


def validate_phone_number(phone_number):
    """
    Validates a phone number format (10 digits).
    
    Args:
        phone_number (str): Phone number to validate.
    
    Returns:
        bool: True if the phone number is valid, False otherwise.
    """
    phone_regex = r'^\d{10}$'
    return re.match(phone_regex, phone_number) is not None


def validate_date(date_str, format="%Y-%m-%d"):
    """
    Validates a date string against a given format.
    
    Args:
        date_str (str): Date string to validate.
        format (str): Expected date format (default is "%Y-%m-%d").
    
    Returns:
        bool: True if the date is valid, False otherwise.
    """
    try:
        datetime.strptime(date_str, format)
        return True
    except ValueError:
        return False


def validate_id(user_id):
    """
    Validates if a user ID is numeric and within a valid range.
    
    Args:
        user_id (str): User ID to validate.
    
    Returns:
        bool: True if the ID is valid, False otherwise.
    """
    return user_id.isdigit() and 1000 <= int(user_id) <= 9999
