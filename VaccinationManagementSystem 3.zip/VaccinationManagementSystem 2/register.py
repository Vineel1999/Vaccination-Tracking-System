import csv

def validate_aadhaar(aadhaar):
    """Validate Aadhaar number format."""
    return len(aadhaar) == 14 and aadhaar[4] == "-" and aadhaar[9] == "-"

def add_registration(details):
    """Add user registration details to vaccination CSV."""
    with open("database/vaccination.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(details)
