import pandas as pd
import matplotlib.pyplot as plt


def generate_report():
    data_file = "database/vaccination.csv"
    output_image = "static/images/vaccination_report.png"

    data = pd.read_csv(data_file)
    vaccine_counts = data["Vaccine"].value_counts()

    plt.bar(vaccine_counts.index, vaccine_counts.values, color="skyblue")
    plt.title("Vaccination Report")
    plt.xlabel("Vaccine")
    plt.ylabel("Count")
    plt.savefig(output_image)
    plt.close()
    return output_image
