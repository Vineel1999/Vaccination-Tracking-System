from flask import Flask, render_template, request, redirect, session
from scheduler import schedule_appointment
from inventory import view_inventory, update_inventory
from reporting import generate_report
import json
from auth import login, initialize_users
from feedback import add_feedback, view_feedback
from register import add_registration, validate_aadhaar

# Load translations
with open("translations.json", "r") as file:
    translations = json.load(file)

app = Flask(__name__)
app.secret_key = "my_secret_key"

# Language setting (default: English)
current_language = "en"


def translate(key):
    return translations.get(current_language, {}).get(key, key)


@app.route("/")
def home():
    return render_template("dashboard.html", translations=translations[current_language])

@app.route("/login", methods=["GET", "POST"])
def login_view():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        role = login(username, password)
        if role:
            session["username"] = username
            session["role"] = role
            return redirect("/")
        return render_template("login.html", translations=translations, error="Invalid credentials!")

    # Render login page with translations
    return render_template("login.html", translations=translations)

@app.route("/logout")
def logout():
    session.clear()
    return render_template("login.html", translations=translations)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        dob = request.form["dob"]
        phone = request.form["phone"]
        email = request.form["email"]
        gender = request.form["gender"]
        aadhaar = request.form["aadhaar"]
        if not validate_aadhaar(aadhaar):
            return "Invalid Aadhaar number!"
        add_registration([name, dob, phone, email, gender, aadhaar])
        return "Registration successful!"
    return render_template("register.html", translations=translations)


@app.route("/schedule", methods=["GET", "POST"])
def schedule():
    if request.method == "POST":
        user_id = request.form["user_id"]
        vaccine_name = request.form["vaccine_name"]
        date = request.form["date"]
        schedule_appointment(user_id, vaccine_name, date)
        return "Appointment scheduled successfully!"
    return render_template("schedule.html", translations=translations[current_language])


@app.route("/inventory", methods=["GET", "POST"])
def inventory():
    if request.method == "POST":
        vaccine_name = request.form["vaccine_name"]
        change_qty = int(request.form["change_qty"])
        update_inventory(vaccine_name, change_qty)
        return "Inventory updated successfully!"
    inventory_data = view_inventory()
    return render_template("inventory.html", inventory=inventory_data, translations=translations[current_language])

@app.route("/update_doses", methods=["GET", "POST"])
def update_doses():
    if request.method == "POST":
        vaccine_name = request.form["vaccine_name"]
        new_quantity = int(request.form["quantity"])
        update_inventory(vaccine_name, new_quantity)
        return "Doses updated successfully!"
    return render_template("update_doses.html", translations=translations)

@app.route("/report")
def report():
    report_image = generate_report()
    return render_template("report.html", report_image=report_image, translations=translations[current_language])

@app.route("/feedback", methods=["GET", "POST"])
def feedback_view():
    if session.get("role") == "admin":
        # Admin role: Only view feedback
        feedback = view_feedback()
        return render_template("feedback.html", feedback=feedback, admin=True, translations=translations)
    elif session.get("role") == "user":
        # User role: Submit feedback and view feedback
        if request.method == "POST":
            name = session.get("username", "Anonymous")  # Get username or default to Anonymous
            message = request.form["message"]
            add_feedback(name, message)  # Save feedback
            success_message = "Thank you for your feedback!"
            feedback = view_feedback()  # Load all feedback for display
            return render_template(
                "feedback.html", feedback=feedback, admin=False, success_message=success_message, translations=translations
            )
        feedback = view_feedback()
        return render_template("feedback.html", feedback=feedback, admin=False, translations=translations)
    else:
        # Redirect non-logged-in users to the login page
        return redirect("/login", translations=translations)



if __name__ == "__main__":
    app.run(debug=True)
